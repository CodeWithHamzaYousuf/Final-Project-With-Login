﻿using Microsoft.AspNetCore.Mvc;
using WebApplication7.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace WebApplication7.Controllers
{
    public class QuizController : Controller
    {
        private static readonly Dictionary<string, List<CareerResult>> _careerMap = new()
        {
            ["Analytical"] = new()
            {
                new("Software Engineer / Developer", "FAST NUCES", new[] {
                    "Ali Khan – Backend Engineer at Google", "Sara Ahmed – Senior Developer at Systems Ltd"
                }, "CS Graduate → Junior Dev → Software Engineer → Tech Lead",
                    "Started at a startup, now a senior engineer at Google.",
                    "Skills: C#, .NET, APIs. Salary: PKR 150k–400k. Outlook: High demand."),

                new("Machine Learning Engineer (BSCS)", "ITU Lahore", new[] {
                    "Dr. Amna – ML Researcher", "Omar Siddiq – AI Engineer at Careem"
                }, "BSCS → ML Intern → Engineer → Lead Data Scientist",
                    "From Kaggle competitions to building AI for healthcare.",
                    "Skills: Python, ML, TensorFlow. Salary: PKR 200k–500k. Outlook: Very high demand."),

                new("Business Analyst", "IBA Karachi", new[] {
                    "Usman Rauf – Analyst at Unilever", "Mehak Tariq – Consultant at PwC"
                }, "Intern → Junior Analyst → Analyst → Strategy Manager",
                    "Analyzed business ops for a bank before switching to consulting.",
                    "Skills: Excel, BI tools, Presentation. Salary: PKR 100k–300k.")
            },

            ["Creative"] = new()
            {
                new("Textile Designer", "NCA Lahore", new[] {
                    "Ayesha Habib – Fabric Artist", "Faisal Moin – Designer at Gul Ahmed"
                }, "Design School → Assistant Designer → Lead Textile Designer",
                    "Interned at Nishat, now runs her own boutique line.",
                    "Skills: Pattern design, Adobe Illustrator. Salary: PKR 70k–200k."),

                new("Fashion Stylist (Fashion)", "Pakistan Institute of Fashion Design", new[] {
                    "Zunaira Ali – Fashion Blogger", "Nashit Gill – Stylist at HSY"
                }, "Stylist Assistant → Freelance → Lead Stylist",
                    "Styled celebrities, now runs a popular Instagram page.",
                    "Skills: Fashion sense, PR. Salary: PKR 80k–250k."),

                new("UI/UX Designer (BSSE)", "LUMS - Design School", new[] {
                    "Dania Sheikh – UI Designer at Daraz", "Haris Murtaza – UX Lead at Bykea"
                }, "BSSE → UI Intern → UX Designer → Product Designer",
                    "Worked on revamping UI for 3 Pakistani startups.",
                    "Skills: Figma, Adobe XD. Salary: PKR 100k–300k.")
            },

            ["Empathetic"] = new()
            {
                new("General Practitioner", "King Edward Medical University", new[] {
                    "Dr. Faisal – GP in Lahore", "Dr. Hina – Family Doctor"
                }, "MBBS → House Job → General Practice",
                    "Opened a local clinic that treats 100+ patients/week.",
                    "Skills: Clinical practice, Communication. Salary: PKR 150k–350k."),

                new("Anesthesiology (MBBS)", "Aga Khan University", new[] {
                    "Dr. Murtaza – Anaesthetist at AKUH", "Dr. Sana – ICU Head"
                }, "MBBS → FCPS → Anaesthetist",
                    "Became head of anesthesia at a major private hospital.",
                    "Skills: Surgery prep, monitoring. Salary: PKR 200k–450k.")
            },

            ["Leadership"] = new()
            {
                new("Operations Manager (BBA)", "Lahore School of Economics", new[] {
                    "Farhan Aziz – Ops at Metro", "Nida Noor – Head Ops at Foodpanda"
                }, "BBA → Coordinator → Ops Exec → Manager",
                    "Started in call center, now manages national logistics.",
                    "Skills: Organization, people management. Salary: PKR 120k–400k."),

                new("Manufacturing Engineer (BSME)", "UET Lahore", new[] {
                    "Junaid Malik – Plant Manager", "Rabia Shams – Process Engineer"
                }, "BSME → Junior Eng → Production Eng → Plant Head",
                    "Improved efficiency at a leading auto parts factory.",
                    "Skills: CAD, QA, production. Salary: PKR 140k–350k."),

                new("Automotive Engineer", "NED University of Engineering", new[] {
                    "Asif Raza – R&D at Pak Suzuki", "Mehran Khan – Auto Systems Designer"
                }, "Intern → Auto Eng → Vehicle Systems Lead",
                    "Worked on Pakistan's first local EV.",
                    "Skills: Mechanical design, AutoCAD. Salary: PKR 120k–300k.")
            }
        };

        private static readonly Random _random = new();

        private static readonly List<QuizQuestion> _questions = new()
{
    new QuizQuestion { Id = 1, Category = "Interest", QuestionText = "What do you enjoy most?", Options = MakeOptions("Solving problems", "Designing", "Helping others", "Leading a team") },

    new QuizQuestion { Id = 2, Category = "Skill", QuestionText = "Which skill are you best at?", Options = MakeOptions("Coding or math", "Drawing or writing", "Listening to people", "Organizing tasks") },

    new QuizQuestion { Id = 3, Category = "Interest", QuestionText = "What’s your favorite hobby?", Options = MakeOptions("Sudoku / puzzles", "Painting / crafts", "Volunteering", "Hosting events") },

    new QuizQuestion { Id = 4, Category = "Personality", QuestionText = "Your friends say you are:", Options = MakeOptions("Precise", "Imaginative", "Caring", "Assertive") },

    new QuizQuestion { Id = 5, Category = "Skill", QuestionText = "Pick one activity you excel at:", Options = MakeOptions("Data analysis", "Photography", "Helping others solve issues", "Team planning") },

    new QuizQuestion { Id = 6, Category = "Value", QuestionText = "What do you value in your career?", Options = MakeOptions("Logic and clarity", "Freedom and expression", "Community and care", "Authority and impact") },

    new QuizQuestion { Id = 7, Category = "Personality", QuestionText = "How do you make decisions?", Options = MakeOptions("With logic", "With intuition", "With empathy", "With confidence") },

    new QuizQuestion { Id = 8, Category = "Interest", QuestionText = "Choose a dream project:", Options = MakeOptions("Build a software", "Design fashion line", "Start a health center", "Lead a startup") },

    new QuizQuestion { Id = 9, Category = "Skill", QuestionText = "Pick the skill that best describes you:", Options = MakeOptions("Critical thinking", "Visual creativity", "Active listening", "Delegation") },

    new QuizQuestion { Id = 10, Category = "Interest", QuestionText = "Favorite school subject?", Options = MakeOptions("Math", "Art", "Biology", "Business") },

    new QuizQuestion { Id = 11, Category = "Skill", QuestionText = "Choose a software skill:", Options = MakeOptions("Excel / Python", "Adobe Creative Suite", "Patient records software", "Project management tools") },

    new QuizQuestion { Id = 12, Category = "Value", QuestionText = "You want a job that lets you:", Options = MakeOptions("Solve hard problems", "Express ideas", "Help people", "Make big decisions") },

    new QuizQuestion { Id = 13, Category = "Personality", QuestionText = "How would you act in a group?", Options = MakeOptions("Logical contributor", "Creative ideator", "Supportive teammate", "Natural leader") },

    new QuizQuestion { Id = 14, Category = "Value", QuestionText = "You’re motivated by:", Options = MakeOptions("Efficiency", "Creativity", "Kindness", "Influence") },

    new QuizQuestion { Id = 15, Category = "Interest", QuestionText = "You prefer to spend time:", Options = MakeOptions("Fixing systems", "Designing logos", "Volunteering", "Delegating work") },

    new QuizQuestion { Id = 16, Category = "Personality", QuestionText = "You often get compliments on your:", Options = MakeOptions("Problem-solving", "Artistic skills", "Compassion", "Leadership") },

    new QuizQuestion { Id = 17, Category = "Value", QuestionText = "In a crisis, you're the one who:", Options = MakeOptions("Stays logical", "Thinks outside the box", "Comforts others", "Takes charge") },
};


        public IActionResult Index()
        {
            return View(_questions);
        }

        [HttpPost]
        public IActionResult Submit(List<QuizResponse> responses)
        {
            var traitCounts = new Dictionary<string, int>();
            foreach (var response in responses)
            {
                var question = _questions.FirstOrDefault(q => q.Id == response.QuestionId);
                var option = question?.Options.FirstOrDefault(o => o.Id == response.SelectedOptionId);
                if (option == null) continue;

                if (!traitCounts.ContainsKey(option.AssociatedTrait))
                    traitCounts[option.AssociatedTrait] = 0;
                traitCounts[option.AssociatedTrait]++;
            }

            var topTrait = traitCounts.OrderByDescending(t => t.Value).First().Key;
            var careers = _careerMap[topTrait];
            var selectedCareer = careers[_random.Next(careers.Count)];

            ViewBag.Trait = topTrait;
            ViewBag.Career = selectedCareer.Career;
            ViewBag.University = selectedCareer.University;
            ViewBag.Eligibility = _random.Next(65, 91);
            ViewBag.Mentors = selectedCareer.Mentors;
            ViewBag.CareerMap = selectedCareer.CareerMap;
            ViewBag.SuccessStory = selectedCareer.SuccessStory;
            ViewBag.JobOverview = selectedCareer.JobOverview;

            return View();
        }

        private static List<QuizOption> MakeOptions(string a, string b, string c, string d)
        {
            return new List<QuizOption>
            {
                new() { Text = a, AssociatedTrait = "Analytical" },
                new() { Text = b, AssociatedTrait = "Creative" },
                new() { Text = c, AssociatedTrait = "Empathetic" },
                new() { Text = d, AssociatedTrait = "Leadership" }
            };
        }

        private record CareerResult(
            string Career,
            string University,
            string[] Mentors,
            string CareerMap,
            string SuccessStory,
            string JobOverview
        );
    }
}
